<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\User;

class ReferralController extends Controller
{
    // My referral logic
    public function my_refer()
    {
        $user = auth()->user();
        $referrals = $user->referrals; // All referrals of the user
        $referralCount = $referrals->count();

//        // Instead of fixed 10, it will now calculate based on generation if needed later
//        $commissionEarned = $referralCount * 10; // Total earned commission for now
//
//        // Calculate the total amount withdrawn by the user
//        $commissionDeducted = $user->withdrawals()->sum('amount');
//
//        if (!$user->has_commission_added) {
//            DB::transaction(function () use ($user, $commissionEarned) {
//                // Update the user's main balance
//                $user->main_balance += $commissionEarned;
//                $user->has_commission_added = true; // Set a flag indicating commission has been added
//                $user->save();
//            });
//        }
//
//        $balance = $user->main_balance - $commissionDeducted;

//        return view('user.referrals.my_refer', compact('user', 'referrals', 'commissionEarned', 'commissionDeducted', 'balance'));
        return view('user.referrals.my_refer', compact('user', 'referrals'));
    }

    // Method to add a referral
    public function addReferral($referrerId, $referredUserId)
    {
        // Logic to add the referred user
        $referrer = User::find($referrerId);
        $referredUser = User::find($referredUserId);

        // Ensure that the referred user is not self or already referred
        if ($referrer && $referredUser && $referrerId != $referredUserId) {
            $referredUser->referred_by = $referrer->id;
            $referredUser->save();

            // Add 10 units to referrer's main balance for the referral
            $referrer->main_balance += 0;
            $referrer->save();
        }
    }

    // Add referral commission recursively based on generation
    public function addReferralCommission($user, $generation = 1) {
        if ($generation > 5 || !$user->referredBy) {
            return; // Limit to 5 generations
        }

        // Get the commission amount for the specific generation
        $commission = $this->getCommissionByGeneration($generation);

        // Add commission to the referrer's main balance
        $user->referredBy->main_balance += $commission;
        $user->referredBy->save();

        // Recursively add commission for the next generation
        $this->addReferralCommission($user->referredBy, $generation + 1);
    }

    // Define commission amounts for each generation
    private function getCommissionByGeneration($generation) {
        switch ($generation) {
            case 1:
                return 29;
            case 2:
                return 10;
            case 3:
                return 5;
            case 4:
                return 2;
            default:
                return 0;
        }
    }
}
